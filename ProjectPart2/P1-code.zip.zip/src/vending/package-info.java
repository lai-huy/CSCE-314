/**
 * Main package
 */
package vending;